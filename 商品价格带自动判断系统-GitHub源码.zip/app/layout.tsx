import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "商品价格带自动判断系统",
  description: "在浏览器本地完成画像规则与商品属性匹配，并导出价格带判断结果。",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="zh-CN">
      <body>{children}</body>
    </html>
  );
}
