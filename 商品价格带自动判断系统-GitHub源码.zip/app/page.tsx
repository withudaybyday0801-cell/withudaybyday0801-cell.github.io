"use client";

import { useMemo, useRef, useState } from "react";
import * as XLSX from "xlsx";

type Row = Record<string, string>;
type Mapping = Record<string, string>;

const PROFILE_FIELDS = [
  ["一级类目", true],
  ["二级类目", true],
  ["三级类目", true],
  ["价格带", true],
  ["模式", true],
  ["画像参数描述", true],
] as const;

const PRODUCT_FIELDS = [
  ["一级类目", true],
  ["二级类目", true],
  ["三级类目", true],
  ["商品id", true],
  ["商品名称", true],
  ["画像价格带", false],
  ["不符合画像价格带原因", false],
] as const;

const OUTPUT_PREFIX = [
  "一级类目",
  "二级类目",
  "三级类目",
  "商品id",
  "商品名称",
];
const OUTPUT_SUFFIX = ["画像价格带", "不符合画像价格带原因"];

function clean(value: unknown) {
  return String(value ?? "").trim();
}

function isMissingValue(value: unknown) {
  const normalized = clean(value).toLowerCase();
  return (
    normalized === "" ||
    normalized === "//" ||
    normalized === "n/a" ||
    /^#(?:n\/a|value!|ref!|div\/0!|name\?|null!)$/i.test(normalized)
  );
}

function parseWorkbook(file: File): Promise<Row[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const workbook = XLSX.read(reader.result, { type: "array" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, {
          defval: "",
          raw: false,
        });
        resolve(
          rows.map((row) =>
            Object.fromEntries(Object.entries(row).map(([key, value]) => [clean(key), clean(value)])),
          ),
        );
      } catch (error) {
        reject(error);
      }
    };
    reader.onerror = reject;
    reader.readAsArrayBuffer(file);
  });
}

function autoMap(columns: string[], fields: readonly (readonly [string, boolean])[]) {
  const aliases: Record<string, string[]> = {
    商品id: ["商品ID", "商品编号", "id"],
    商品名称: ["商品标题", "标题", "品名"],
    材质: ["材料", "面料"],
    容量: ["规格", "容量规格"],
    价格带: ["价格带区间", "画像价格带"],
    模式: ["画像模式", "case when"],
    画像参数描述: ["画像参数", "参数描述", "画像规则", "规则描述"],
  };
  return Object.fromEntries(
    fields.map(([field]) => {
      const candidates = [field, ...(aliases[field] ?? [])].map((value) => value.toLowerCase());
      const match =
        columns.find((column) => candidates.includes(column.toLowerCase())) ??
        columns.find((column) =>
          candidates.some(
            (candidate) =>
              column.toLowerCase().includes(candidate) || candidate.includes(column.toLowerCase()),
          ),
        );
      return [field, match ?? ""];
    }),
  );
}

function mapRows(rows: Row[], mapping: Mapping) {
  return rows.map((row) =>
    Object.fromEntries(
      Object.entries(mapping).map(([field, column]) => [field, column ? clean(row[column]) : ""]),
    ),
  );
}

function mapProductRows(rows: Row[], mapping: Mapping) {
  return rows.map((row) => ({
    ...row,
    ...Object.fromEntries(
      Object.entries(mapping).map(([field, column]) => [field, column ? clean(row[column]) : ""]),
    ),
  }));
}

function optionValues(source: string) {
  const quoted = [...source.matchAll(/["'“”‘’]([^"'“”‘’]+)["'“”‘’]/g)].map((match) =>
    clean(match[1]),
  );
  if (quoted.length) return quoted;
  return source
    .replace(/[\[\]（）()]/g, "")
    .split(/[/、,，|；;]/)
    .map(clean)
    .filter(Boolean);
}

function capacityValues(source: string) {
  return [...clean(source).toLowerCase().matchAll(/(\d+(?:\.\d+)?)\s*(ml|毫升|l|升)/g)].map(
    (match) => Number(match[1]) * (match[2] === "l" || match[2] === "升" ? 1000 : 1),
  );
}

function textMatches(actual: string, options: string[]) {
  if (isMissingValue(actual)) return false;
  const value = clean(actual).toLowerCase();
  return options.some((option) => {
    const expected = clean(option).toLowerCase();
    return !isMissingValue(expected) && value.includes(expected);
  });
}

function capacityMatches(actual: string, options: string[]) {
  if (isMissingValue(actual)) return false;
  const actualValues = capacityValues(actual);
  if (actualValues.length) {
    return options.some((option) => {
      const expectedValues = capacityValues(option);
      if (!expectedValues.length) return textMatches(actual, [option]);
      const expected = expectedValues[0];
      if (/≥|>=|不少于|不低于|以上/.test(option)) {
        return actualValues.some((value) => value >= expected);
      }
      if (/≤|<=|不多于|不高于|以下/.test(option)) {
        return actualValues.some((value) => value <= expected);
      }
      if (/>|大于|高于/.test(option)) {
        return actualValues.some((value) => value > expected);
      }
      if (/<|小于|低于/.test(option)) {
        return actualValues.some((value) => value < expected);
      }
      if (/[-~至到]/.test(option) && expectedValues.length >= 2) {
        const minimum = Math.min(expectedValues[0], expectedValues[1]);
        const maximum = Math.max(expectedValues[0], expectedValues[1]);
        return actualValues.some((value) => value >= minimum && value <= maximum);
      }
      return actualValues.some((value) => Math.abs(value - expected) < 0.01);
    });
  }
  return textMatches(actual, options);
}

type RuleClause = {
  field: string;
  options: string[];
  negated: boolean;
};

type RuleGroup = {
  clauses: RuleClause[];
  operator: "AND" | "OR";
  globalFallback: boolean;
};

function normalizeRuleField(field: string) {
  const normalized = clean(field).replace(/^(?:AND|OR|并且|而且|以及|且|或)+/i, "");
  if (/^(?:商品名称|商品标题|标题)(?:关键词)?$/.test(normalized)) return "商品名称";
  if (normalized === "材料") return "材质";
  return normalized;
}

function splitRuleTerms(description: string) {
  const terms: string[] = [];
  const source = clean(description).replaceAll("（", "(").replaceAll("）", ")");
  let buffer = "";
  let depth = 0;
  for (const character of source) {
    if (character === "(") depth += 1;
    if (character === ")") depth -= 1;
    if (character === "+" && depth === 0) {
      if (clean(buffer)) terms.push(clean(buffer));
      buffer = "";
    } else {
      buffer += character;
    }
  }
  if (clean(buffer)) terms.push(clean(buffer));
  return terms;
}

function stripOuterParentheses(source: string) {
  let value = clean(source);
  while (value.startsWith("(") && value.endsWith(")")) {
    let depth = 0;
    let enclosesWholeValue = true;
    for (let index = 0; index < value.length; index += 1) {
      if (value[index] === "(") depth += 1;
      if (value[index] === ")") depth -= 1;
      if (depth === 0 && index < value.length - 1) {
        enclosesWholeValue = false;
        break;
      }
    }
    if (!enclosesWholeValue) break;
    value = clean(value.slice(1, -1));
  }
  return value;
}

function parseRule(description: string) {
  return splitRuleTerms(description).map((term): RuleGroup => {
    const source = stripOuterParentheses(term);
    const clauses: RuleClause[] = [];
    const pattern =
      /(?:^|或|\bOR\b|并且|而且|以及|且|\bAND\b)\s*([A-Za-z0-9_%\u4e00-\u9fff]{1,30}?)\s*(?:(不包含|不等于|不为|不是|为|是|包含|等于|[:：]))?\s*[【[]([\s\S]*?)[】\]]/gi;
    let match: RegExpExecArray | null;
    while ((match = pattern.exec(source))) {
      clauses.push({
        field: normalizeRuleField(match[1]),
        options: optionValues(match[3] ?? ""),
        negated: /^(?:不包含|不等于|不为|不是)$/.test(match[2] ?? ""),
      });
    }
    const titleOnly = clauses.every((clause) => clause.field === "商品名称");
    return {
      clauses,
      operator: /或|\bOR\b/i.test(source) ? "OR" : "AND",
      globalFallback: clauses.length > 0 && titleOnly && /^(?:或|\bOR\b)/i.test(source),
    };
  });
}

function productValue(product: Row, field: string) {
  if (field === "商品名称") return product.商品名称;
  if (field === "材质") return product.材质 || product.材料 || "";
  const exact = Object.keys(product).find((key) => key.toLowerCase() === field.toLowerCase());
  return exact ? product[exact] : "";
}

function numberValues(source: string) {
  return [...clean(source).matchAll(/-?\d+(?:\.\d+)?/g)].map((match) => Number(match[0]));
}

function escapeRegExp(source: string) {
  return source.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function contextualNumberValues(actual: string, option: string, field: string) {
  if (field !== "成分含量") return numberValues(actual);
  const firstNumber = clean(option).search(/\d/);
  if (firstNumber < 0) return numberValues(actual);
  const labelSource = clean(option).slice(0, firstNumber);
  const labels = [...labelSource.matchAll(/[A-Za-z\u4e00-\u9fff]+/g)]
    .map((match) => clean(match[0]))
    .filter((label) => label && !["成分", "含量", "百分比"].includes(label));
  if (!labels.length) return numberValues(actual);
  const values = labels.flatMap((label) => {
    const pattern = new RegExp(`${escapeRegExp(label)}[^0-9-]{0,20}(-?\\d+(?:\\.\\d+)?)`, "gi");
    return [...clean(actual).matchAll(pattern)].map((match) => Number(match[1]));
  });
  return values;
}

function numericMatches(actual: string, options: string[], field: string) {
  if (isMissingValue(actual)) return false;
  return options.some((option) => {
    const actualValues = contextualNumberValues(actual, option, field);
    if (!actualValues.length) return false;
    const expectedValues = numberValues(option);
    if (!expectedValues.length) return textMatches(actual, [option]);
    const expected = expectedValues[0];
    if (/≥|>=|不少于|不低于|以上/.test(option)) {
      return actualValues.some((value) => value >= expected);
    }
    if (/≤|<=|不多于|不高于|以下/.test(option)) {
      return actualValues.some((value) => value <= expected);
    }
    if (/>|大于|高于/.test(option)) {
      return actualValues.some((value) => value > expected);
    }
    if (/<|小于|低于/.test(option)) {
      return actualValues.some((value) => value < expected);
    }
    if (/[-~至到]/.test(option) && expectedValues.length >= 2) {
      const minimum = Math.min(expectedValues[0], expectedValues[1]);
      const maximum = Math.max(expectedValues[0], expectedValues[1]);
      return actualValues.some((value) => value >= minimum && value <= maximum);
    }
    return textMatches(actual, [option]);
  });
}

function clauseMatches(product: Row, clause: RuleClause) {
  if (!clause.options.length) return false;
  const actual = productValue(product, clause.field);
  if (isMissingValue(actual)) return false;
  let matched: boolean;
  if (clause.field === "容量") {
    matched = capacityMatches(actual, clause.options);
  } else if (
    clause.options.some((option) =>
      /≥|<=|≤|>=|>|<|不少于|不低于|不多于|不高于|以上|以下|[-~至到]/.test(option),
    )
  ) {
    matched = numericMatches(actual, clause.options, clause.field);
  } else {
    matched = textMatches(actual, clause.options);
  }
  return clause.negated ? !matched : matched;
}

function clauseFailureReason(product: Row, clause: RuleClause) {
  const required = clause.options.join(" / ");
  const actual = productValue(product, clause.field);
  if (isMissingValue(actual)) {
    return `${clause.field}缺失：画像要求“${required}”`;
  }
  if (clause.negated) {
    if (clause.field === "商品名称") {
      return `商品名称包含了禁止关键词“${required}”`;
    }
    return `${clause.field}包含了禁止值：当前“${actual}”，不得包含“${required}”`;
  }
  if (clause.field === "商品名称") {
    return `商品名称未包含关键词“${required}”`;
  }
  return `${clause.field}不符合：当前“${actual || "空"}”，要求“${required}”`;
}

function evaluateProfile(product: Row, profile: Row) {
  const groups = parseRule(profile.画像参数描述);
  const validGroups = groups.filter((group) => group.clauses.length > 0);
  if (!validGroups.length) {
    return { matched: false, failures: ["画像参数描述无法识别"] };
  }

  const groupMatches = (group: RuleGroup) =>
    group.operator === "OR"
      ? group.clauses.some((clause) => clauseMatches(product, clause))
      : group.clauses.every((clause) => clauseMatches(product, clause));
  const requiredGroups = validGroups.filter((group) => !group.globalFallback);
  const fallbackGroups = validGroups.filter((group) => group.globalFallback);
  const requiredMatched =
    requiredGroups.length > 0 && requiredGroups.every((group) => groupMatches(group));
  const fallbackMatched = fallbackGroups.some((group) => groupMatches(group));
  const failures = requiredGroups.flatMap((group) => {
    if (groupMatches(group)) return [];
    const reasons = group.clauses
      .filter((clause) => !clauseMatches(product, clause))
      .map((clause) => clauseFailureReason(product, clause));
    return group.operator === "OR" && reasons.length > 1
      ? [`括号内OR条件均未满足：${reasons.join("；")}`]
      : reasons;
  });
  if (!fallbackMatched) {
    failures.push(
      ...fallbackGroups.flatMap((group) =>
        group.clauses.map((clause) => `整条画像OR兜底未满足：${clauseFailureReason(product, clause)}`),
      ),
    );
  }
  return {
    matched: requiredMatched || fallbackMatched,
    failures,
  };
}

function priceUpper(priceBand: string) {
  const values = [...clean(priceBand).matchAll(/\d+(?:\.\d+)?/g)].map((match) => Number(match[0]));
  return values.length ? Math.max(...values) : 0;
}

function categoryKey(row: Row) {
  return [row.一级类目, row.二级类目, row.三级类目].map(clean).join("｜");
}

function runMatcher(profiles: Row[], products: Row[]) {
  const byCategory = new Map<string, Array<Row & { __order: string }>>();
  profiles.forEach((profile, index) => {
    const category = categoryKey(profile);
    const item = { ...profile, __order: String(index) };
    byCategory.set(category, [...(byCategory.get(category) ?? []), item]);
  });

  return products.map((product) => {
    const candidates = byCategory.get(categoryKey(product)) ?? [];
    const evaluations = candidates.map((profile) => ({
      profile,
      ...evaluateProfile(product, profile),
    }));
    const matches = evaluations.filter((evaluation) => evaluation.matched);
    matches.sort(
      (left, right) =>
        Number(right.profile.__order) - Number(left.profile.__order) ||
        priceUpper(right.profile.价格带) - priceUpper(left.profile.价格带),
    );
    const winner = matches[0]?.profile;
    const closest = [...evaluations]
      .filter((evaluation) => !evaluation.matched)
      .sort(
        (left, right) =>
          left.failures.length - right.failures.length ||
          Number(right.profile.__order) - Number(left.profile.__order),
      )[0];
    const reason =
      candidates.length === 0
        ? `类目无对应画像规则：${product.一级类目 || "空"} / ${product.二级类目 || "空"} / ${product.三级类目 || "空"}`
        : winner
          ? ""
          : `最接近画像“${closest?.profile.模式 || "未命名"}”（${closest?.profile.价格带 || "无价格带"}）：${closest?.failures.join("；") || "未满足画像条件"}`;
    return {
      ...product,
      一级类目: product.一级类目,
      二级类目: product.二级类目,
      三级类目: product.三级类目,
      商品id: product.商品id,
      商品名称: product.商品名称,
      画像价格带: winner?.价格带 ?? "",
      不符合画像价格带原因: reason,
    };
  });
}

function FileZone({
  title,
  description,
  fileName,
  rowCount,
  onFile,
}: {
  title: string;
  description: string;
  fileName: string;
  rowCount: number;
  onFile: (file: File) => void;
}) {
  const input = useRef<HTMLInputElement>(null);
  const loaded = rowCount > 0;
  return (
    <button
      type="button"
      className={`upload-zone ${loaded ? "loaded" : ""}`}
      onClick={() => input.current?.click()}
      onDragOver={(event) => event.preventDefault()}
      onDrop={(event) => {
        event.preventDefault();
        const file = event.dataTransfer.files[0];
        if (file) onFile(file);
      }}
    >
      <input
        ref={input}
        type="file"
        hidden
        accept=".xlsx,.xls,.csv"
        onChange={(event) => {
          const file = event.target.files?.[0];
          if (file) onFile(file);
        }}
      />
      <span className="upload-icon">{loaded ? "✓" : "＋"}</span>
      <strong>{title}</strong>
      <small>{loaded ? `${fileName} · ${rowCount} 条数据` : description}</small>
    </button>
  );
}

function Mapper({
  title,
  fields,
  columns,
  mapping,
  setMapping,
}: {
  title: string;
  fields: readonly (readonly [string, boolean])[];
  columns: string[];
  mapping: Mapping;
  setMapping: (mapping: Mapping) => void;
}) {
  return (
    <div className="mapper">
      <h3>{title}</h3>
      <div className="mapping-grid">
        {fields.map(([field, required]) => (
          <label key={field}>
            <span>
              {field}
              {required && <em>*</em>}
            </span>
            <select
              value={mapping[field] ?? ""}
              onChange={(event) => setMapping({ ...mapping, [field]: event.target.value })}
            >
              <option value="">— 不映射 —</option>
              {columns.map((column) => (
                <option key={column} value={column}>
                  {column}
                </option>
              ))}
            </select>
          </label>
        ))}
      </div>
    </div>
  );
}

function Step({ number, title, done }: { number: number; title: string; done?: boolean }) {
  return (
    <div className="step-title">
      <span className={done ? "done" : ""}>{done ? "✓" : number}</span>
      <h2>{title}</h2>
    </div>
  );
}

export default function Home() {
  const [profileRaw, setProfileRaw] = useState<Row[]>([]);
  const [productRaw, setProductRaw] = useState<Row[]>([]);
  const [profileName, setProfileName] = useState("");
  const [productName, setProductName] = useState("");
  const [profileMap, setProfileMap] = useState<Mapping>({});
  const [productMap, setProductMap] = useState<Mapping>({});
  const [results, setResults] = useState<Row[]>([]);
  const [error, setError] = useState("");
  const [running, setRunning] = useState(false);

  const profileColumns = useMemo(() => Object.keys(profileRaw[0] ?? {}), [profileRaw]);
  const productColumns = useMemo(() => Object.keys(productRaw[0] ?? {}), [productRaw]);
  const resultColumns = useMemo(() => {
    const mappedSourceColumns = new Set(Object.values(productMap).filter(Boolean));
    const dynamicColumns = productColumns.filter(
      (column) =>
        !mappedSourceColumns.has(column) &&
        !OUTPUT_PREFIX.includes(column) &&
        !OUTPUT_SUFFIX.includes(column),
    );
    return [...OUTPUT_PREFIX, ...dynamicColumns, ...OUTPUT_SUFFIX];
  }, [productColumns, productMap]);
  const mappingsValid =
    profileRaw.length > 0 &&
    productRaw.length > 0 &&
    PROFILE_FIELDS.filter(([, required]) => required).every(([field]) => profileMap[field]) &&
    PRODUCT_FIELDS.filter(([, required]) => required).every(([field]) => productMap[field]);
  const matched = results.filter((row) => row.画像价格带).length;

  async function loadFile(file: File, type: "profile" | "product") {
    try {
      setError("");
      const rows = await parseWorkbook(file);
      if (!rows.length) throw new Error("文件中没有可读取的数据");
      if (type === "profile") {
        setProfileRaw(rows);
        setProfileName(file.name);
        setProfileMap(autoMap(Object.keys(rows[0]), PROFILE_FIELDS));
      } else {
        setProductRaw(rows);
        setProductName(file.name);
        setProductMap(autoMap(Object.keys(rows[0]), PRODUCT_FIELDS));
      }
      setResults([]);
    } catch (err) {
      setError(err instanceof Error ? err.message : "文件解析失败");
    }
  }

  function match() {
    if (!mappingsValid) return;
    setRunning(true);
    setError("");
    window.setTimeout(() => {
      try {
        setResults(
          runMatcher(mapRows(profileRaw, profileMap), mapProductRows(productRaw, productMap)),
        );
      } catch (err) {
        setError(err instanceof Error ? err.message : "匹配失败");
      } finally {
        setRunning(false);
      }
    }, 80);
  }

  function exportResults() {
    const exportRows = results.map((row) =>
      Object.fromEntries(resultColumns.map((column) => [column, row[column] ?? ""])),
    );
    const worksheet = XLSX.utils.json_to_sheet(exportRows, { header: resultColumns });
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "匹配结果");
    XLSX.writeFile(workbook, "商品价格带匹配结果.xlsx");
  }

  return (
    <main>
      <header className="hero">
        <div className="brand">价格带智配</div>
        <div className="hero-copy">
          <div className="eyebrow">LOCAL RULE ENGINE · 数据不出浏览器</div>
          <h1>
            商品价格带
            <br />
            自动判断系统
          </h1>
          <p>上传画像规则和商品明细，系统自动识别商品属性列并完成价格带归类。</p>
        </div>
        <div className="hero-flow" aria-label="使用流程">
          <span>01 上传文件</span>
          <i />
          <span>02 确认映射</span>
          <i />
          <span>03 生成结果</span>
        </div>
      </header>

      <section className="workspace">
        <article className="card">
          <Step number={1} title="上传数据文件" done={profileRaw.length > 0 && productRaw.length > 0} />
          <p className="section-note">支持 Excel（.xlsx / .xls）和 CSV，文件仅在本机浏览器中解析。</p>
          <div className="upload-grid">
            <FileZone
              title="画像规则表"
              description="一级/二级/三级类目、价格带、模式、画像参数描述"
              fileName={profileName}
              rowCount={profileRaw.length}
              onFile={(file) => loadFile(file, "profile")}
            />
            <FileZone
              title="待判断商品表"
              description="固定基础字段 + 任意动态商品属性列"
              fileName={productName}
              rowCount={productRaw.length}
              onFile={(file) => loadFile(file, "product")}
            />
          </div>
        </article>

        {(profileRaw.length > 0 || productRaw.length > 0) && (
          <article className="card">
            <Step number={2} title="确认字段映射" done={mappingsValid} />
            <p className="section-note">系统已按图示列名自动匹配。带 * 的字段必须完成映射。</p>
            {profileRaw.length > 0 && (
              <Mapper
                title="画像规则表"
                fields={PROFILE_FIELDS}
                columns={profileColumns}
                mapping={profileMap}
                setMapping={setProfileMap}
              />
            )}
            {productRaw.length > 0 && (
              <>
                <Mapper
                  title="待判断商品表（仅确认固定字段）"
                  fields={PRODUCT_FIELDS}
                  columns={productColumns}
                  mapping={productMap}
                  setMapping={setProductMap}
                />
                <p className="section-note">
                  其余列将自动作为动态商品属性保留，并按画像参数描述中的同名字段参与判断。
                </p>
              </>
            )}
          </article>
        )}

        <article className="card action-card">
          <Step number={3} title="运行判断" done={results.length > 0} />
          <div className="actions">
            <button className="primary" disabled={!mappingsValid || running} onClick={match}>
              {running ? "正在判断…" : "开始匹配价格带"}
            </button>
            {results.length > 0 && (
              <button className="secondary" onClick={exportResults}>
                导出 Excel
              </button>
            )}
            <span>
              {mappingsValid
                ? `准备处理 ${productRaw.length} 条商品`
                : "请先上传文件并完成必填字段映射"}
            </span>
          </div>
        </article>

        {error && <div className="error">{error}</div>}

        {results.length > 0 && (
          <article className="card results">
            <div className="results-head">
              <div>
                <span className="eyebrow">MATCHING COMPLETE</span>
                <h2>匹配结果</h2>
              </div>
              <div className="stats">
                <span>
                  <b>{results.length}</b> 总数
                </span>
                <span className="success">
                  <b>{matched}</b> 已匹配
                </span>
                <span className="warning">
                  <b>{results.length - matched}</b> 未匹配
                </span>
              </div>
            </div>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    {resultColumns.map((column) => (
                      <th key={column}>{column}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {results.map((row, index) => (
                    <tr
                      key={`${row.商品id}-${index}`}
                      className={row.画像价格带 ? "" : "unmatched"}
                    >
                      {resultColumns.map((column) => (
                        <td key={column}>{row[column] || "—"}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </article>
        )}
      </section>

      <footer>本地规则引擎 · 动态商品属性 / 数值比较 / 商品名称 / AND 与 OR 条件</footer>
    </main>
  );
}
